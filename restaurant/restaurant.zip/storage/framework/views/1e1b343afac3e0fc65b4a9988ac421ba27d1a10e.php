<?php $__env->startSection('sidebar'); ?>

##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##

Delivery

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
        <div class="col-12">
          <div class="card-box">
                <h4 class="header-title mb-4">Delivery Boys</h4>
                <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tickets-table">
                  <thead>
                        <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Contact</th>
                          <th>Permanent Address</th>
                          <th>Address Map</th>
                        </tr>
                  </thead>
                  <tbody>
                        <?php $__currentLoopData = $delivery_boys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery_boy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                          <tr>
                                 <td>
                                  <?php echo e($delivery_boy->id); ?>

                                </td>
                                <td>
                                  <?php echo e($delivery_boy->name); ?>

                                </td>
                                <td>
                                  <?php echo e($delivery_boy->email); ?>

                                </td>
                                
                                <td>
                                  <?php echo e($delivery_boy->contact); ?>

                                </td>
                                <td>
                                  <?php echo e($delivery_boy->permanent_address); ?>

                                </td>
                                <td>
                                   <button type="button" class="btn btn-info waves-effect waves-light map-address btn-xs" data-value="<?php echo e($delivery_boy->id); ?>"><i class="fas fa-map-marker-alt"></i></button>
                                </td>
                              
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
          </div>
        </div><!-- end col -->
  </div>

    <!-- end row-->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-dashboard'); ?>
  <script type="text/javascript">
     $(document).ready(function() {
        $('.map-address').on('click',function() {

            var header = `<h3 class="pull-left" id="myModalLabel" style="margin: 0;font-weight: 600;">Address Map</h3>
                <i  class="pull-right fa fa-bank class-fa"></i>`;
      
            var user_id = $(this).data('value');
            modal(header,'loading','','',false,function(modal_Id) {
              $.ajax({
                url: "<?php echo e(route('delivery-boys.map')); ?>",
                type : 'post',
                data: {user_id: user_id,'_token': $('meta[name=csrf-token]').attr('content')},
                dataType: "json",
                success: function(data ) {
                  $('#'+modal_Id).find('.modal-body').html(data.response);
                  
                },
              });
            });
          });
        
      });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin-layout.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\restaurant\resources\views/admin/delivery-boys/index.blade.php ENDPATH**/ ?>
<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8" />

    <title>Restaurant</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">



    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->

    <link rel="shortcut icon" href="assets/images/favicon.ico">



    <!-- App css -->

    <link href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('public/assets/css/icons.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('public/assets/css/app.min.css')); ?>" rel="stylesheet">



</head>



<body class="authentication-bg authentication-bg-pattern">



    <div class="account-pages mt-5 mb-5">

        <div class="container">

            <div class="row justify-content-center">

                <div class="col-md-8 col-lg-6 col-xl-5">

                    <div class="card">



                        <div class="card-body p-4">



                            <div class="text-center w-75 m-auto">




                                <span>
                                    <h3>Dlv Express</h3>


                                    <p class="text-muted mb-4 mt-3">Enter your email address and password to access admin panel.</p>

                                </div>



                                <h5 class="auth-title">Sign In</h5>



                                 <form method="POST" action="<?php echo e(route('login')); ?>">
                                    <?php echo csrf_field(); ?>



                                    <div class="form-group mb-3">

                                        <label for="emailaddress">Email address</label>

                                        <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Enter your Email">

                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>



                                    <div class="form-group mb-3">

                                        <label for="password">Password</label>

                                        <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Enter your password">

                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>



                                    <div class="form-group mb-3">

                                        <div class="custom-control custom-checkbox checkbox-info">

                                             <input class="custom-control-input" type="checkbox" name="remember" id="checkbox-signin" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                            <label class="custom-control-label" for="checkbox-signin">Remember me</label>

                                        </div>

                                    </div>



                                    <div class="form-group mb-0 text-center">

                                     <button type="submit" class="btn btn-danger btn-block">
                                        <?php echo e(__('Login')); ?>

                                    </button>

                                    </div>



                                </form>



                            </div> <!-- end card-body -->

                        </div>

                        <!-- end card -->



                        

                        <!-- end row -->



                    </div> <!-- end col -->

                </div>

                <!-- end row -->

            </div>

            <!-- end container -->

        </div>

        <!-- end page -->





        <footer class="footer footer-alt">

            2019 &copy; by <a href="" class="text-muted">Dlv Express</a> 

        </footer>



        <!-- Vendor js -->

        <script src="<?php echo e(URL::asset('public/assets/js/vendor.min.js')); ?>"></script>



        <!-- App js -->

        <script src="<?php echo e(URL::asset('public/assets/js/app.min.js')); ?>"></script>



    </body>

    </html><?php /**PATH C:\xampp\htdocs\restaurant\restaurant\resources\views/auth/login.blade.php ENDPATH**/ ?>
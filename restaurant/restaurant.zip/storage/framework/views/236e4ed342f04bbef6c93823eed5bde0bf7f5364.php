<?php $__env->startSection('sidebar'); ?>

##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##

Order

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
        <div class="col-12">
          <div class="card-box">
                <h4 class="header-title mb-4">All Orders</h4>
                <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100" id="tickets-table">
                  <thead>
                        <tr>
                          <th>#</th>
                          <th>Customer Name</th>
                          <th>Driver Name</th>
                          <th>Order Price</th>
                          <th>Restaurant</th>
                          <th>Status</th>
                          <th >Action</th>
                        </tr>
                  </thead>
                  <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                          <tr>
                                <td>
                                    <?php echo e($order->id); ?>

                                </td>
                                <td>
                                    <?php echo e($order->customer_name); ?>

                                </td>
                                <td>
                                    <?php echo e($order->customer_name); ?>

                                </td>
                                <td>
                                    <?php echo e($order->contact); ?>

                                </td>
                                <td>
                                    <?php echo e(WebHelper::get_restaurant_name($order->fk_restaurant_id)); ?>

                                </td>
                                <td>
                                  <span  class="badge badge-<?php echo e(WebHelper::get_order_status($order->status)); ?> waves-effect waves-light "><?php echo e(WebHelper::upperfirst($order->status)); ?>

                                  </span>
                                </td>
                                <td>
                                   
                                    <a href="<?php echo e(route('view.order',$order->id)); ?>" class="btn btn-purple btn-xs waves-effect waves-light view-order" ><i class="fas fa-info-circle"></i></a>
                                </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
          </div>
        </div><!-- end col -->
  </div>

    <!-- end row-->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script-dashboard'); ?>

<?php echo $__env->make('admin-layout.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\restaurant\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('sidebar'); ?>

##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##

Setting

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">

            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Admin Setting</h4>
                    <form role="form" method="POST" id="submit_form" action="<?php echo e(route('update.settings')); ?>" >
                        <?php echo e(csrf_field()); ?>


                        <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="form-group">
                            <label class="col-form-label"><?php echo e(WebHelper::upperfirst($setting->name)); ?></label>
                           
                                <input type="text" class="form-control" required="required" name="key[]" value="<?php echo e($setting->key); ?>" >
                                 <input type="hidden" value="<?php echo e($setting->name); ?>" name="name[]"/> 
                        </div>
                      
                       
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       

                        <button type="submit" class="btn btn-info waves-effect waves-light">
                            Update
                            <span class="btn-label-right"><i class="fas fa-plus-circle"></i>
                            </span>

                        </button>
                    </form>
                </div> <!-- end card-body -->

            </div> <!-- end card-->

        </div> <!-- end col -->

    </div>

    <!-- end row -->



<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin-layout.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\restaurant\resources\views/admin/settings/edit.blade.php ENDPATH**/ ?>
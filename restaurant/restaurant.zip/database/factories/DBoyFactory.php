<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\DBoy;
use Faker\Generator as Faker;

$factory->define(DBoy::class, function (Faker $faker) {
    return [
        //
    ];
});

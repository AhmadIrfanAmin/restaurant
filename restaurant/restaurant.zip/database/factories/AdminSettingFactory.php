<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\AdminSetting;
use Faker\Generator as Faker;

$factory->define(AdminSetting::class, function (Faker $faker) {
    return [
        //
    ];
});
